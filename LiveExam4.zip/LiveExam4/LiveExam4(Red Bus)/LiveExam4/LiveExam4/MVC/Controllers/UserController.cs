using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repository.Implementation;
using Repository.Interface;
using Repository.Models;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class UserController : Controller
    {
        private readonly ILogger<UserController> _logger;
        private readonly IBookingRepository _bookingRepository;

        public UserController(ILogger<UserController> logger, IBookingRepository bookingRepository)
        {
            _logger = logger;
            _bookingRepository = bookingRepository;
        }



        [HttpGet]
        public IActionResult UserDashboard()
        {
            return View();
        }

        [HttpGet]
        public IActionResult ViewBooking()
        {
            ViewBag.tr = _bookingRepository.fetchTrip();
            if (ViewBag.tr == null)
            {
                return RedirectToAction("Error", "Home");
            }
            return View();
        }

        [HttpPost]
        public IActionResult ViewBooking(TripModel tripModel)
        {
            _bookingRepository.AddBooking(tripModel);
            return View();
        }

        [HttpGet]
        public IActionResult BookingDetails()
        {
            var details = _bookingRepository.FetchBooking();
            return View(details);
        }

        [HttpGet]
        public IActionResult GetTripDetails(string trip)
        {
            var tripDetails = _bookingRepository.GetTripDetails(trip);
            return Json(tripDetails);
        }

        [HttpPost]
        public IActionResult CancelBooking(int id)
        {
            _bookingRepository.CancelBooking(id);
            return RedirectToAction("BookingDetails");
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}
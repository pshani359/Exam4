using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repository.Models;

namespace Repository.Interface
{
    public interface IBookingRepository
    {
        bool AddBooking(TripModel tripModel);
        List<BookModel> FetchBooking();
        List<TripModel> fetchTrip();
        TripModel GetTripDetails(string trip);
        void CancelBooking(int id);
    }
}
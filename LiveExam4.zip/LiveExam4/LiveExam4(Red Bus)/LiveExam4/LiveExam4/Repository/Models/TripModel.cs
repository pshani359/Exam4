using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repository.Models
{
    public class TripModel
    {
          public int c_tid {get; set;}
        public string? c_trip{get;set;}
        public double c_price{get;set;}
        public int c_tstock{get;set;}
        public int c_cstock{get;set;}
        public int c_qty{get;set;}
        public double c_tcost{get;set;}
        public DateTime c_tdate{get;set;}
        public int c_status{get;set;}
    }
}